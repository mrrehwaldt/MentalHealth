(function(){

  $('.carousel.carousel-slider').carousel({fullWidth: true});

$(document).ready(function(){
      $('.carousel').carousel();
    });

})();
